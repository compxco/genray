/*-----------------------------------------------------------------------------
|	menu.h
-----------------------------------------------------------------------------*/
extern void init_menus();
extern void set_selected_iwin(int);
extern void menu_setwindows(int);

