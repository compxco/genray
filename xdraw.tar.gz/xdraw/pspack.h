#ifndef noPROTO
extern  void main(int argc,char * *argv);
extern  void readsize(void );
extern	void input(char *p,char *q);
#endif

