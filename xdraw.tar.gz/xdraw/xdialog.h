/******************************************************************************
**  NAME            xdialog.h
**  AUTHOR          Sheryl M. Glasser
**
**  DESCRIPTION
**
**
**  Copyright (c) GlassWare 1994.  All rights reserved.
******************************************************************************/
Widget CreateEditDialog(Widget parent, int selected, Display *disp);

