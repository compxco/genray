/***************************************
*	wtest.h
***************************************/
#define WT_QUIT		1
#define WT_MSG		2
#define WT_ARROW	3
#define WT_CROSS	4

